module.exports = {
    "apps": [
        {
            "name": "realWorld",
            "script": "start.js"
        }
    ]
};

