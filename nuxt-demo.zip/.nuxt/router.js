import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _92f6eb4a = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _00b2c760 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _153593d0 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _0a16e098 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _6bf579d8 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _aa949ec4 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _1e3db836 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _92f6eb4a,
    children: [{
      path: "",
      component: _00b2c760,
      name: "home"
    }, {
      path: "/login",
      component: _153593d0,
      name: "login"
    }, {
      path: "/register",
      component: _153593d0,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _0a16e098,
      name: "profile"
    }, {
      path: "/settings",
      component: _6bf579d8,
      name: "settings"
    }, {
      path: "/editor",
      component: _aa949ec4,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _1e3db836,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
