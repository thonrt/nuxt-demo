const cmd = require("node-cmd");
cmd.run("npm start");